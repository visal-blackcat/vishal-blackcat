from pypdf import PdfReader
import urllib.request

url = 'https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Common-Credentials/10k-most-common.txt'
words = urllib.request.urlopen(url, timeout=30).read().decode('utf-8', 'ignore').splitlines()
print(f'Loaded {len(words)} candidates')

path = r'C:\Users\USER\Downloads\W_4\pdf_hash\patient_report_3.pdf'
r = PdfReader(path)
print('Encrypted:', r.is_encrypted)

for i, pw in enumerate(words):
    pw = pw.strip()
    if not pw:
        continue
    try:
        if r.decrypt(pw):
            print(f'PASSWORD FOUND at index {i}: {pw!r}')
            txt = '\n'.join((p.extract_text() or '') for p in r.pages)
            print(txt[:3000])
            with open(r'C:\Users\USER\Downloads\W_4\pdf3_password.txt', 'w') as f:
                f.write(pw)
            break
    except Exception:
        pass
else:
    print('No match in common list')
