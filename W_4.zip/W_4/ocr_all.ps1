Add-Type -AssemblyName System.Runtime.WindowsRuntime

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]

function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}

[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine,Windows.Media.Ocr,ContentType=WindowsRuntime] | Out-Null

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage('en-US') }

$dirs = @('C:\Users\USER\Downloads\W_4\pdf_hash', 'C:\Users\USER\Downloads\W_4\proof')
$outDir = 'C:\Users\USER\Downloads\W_4\ocr_output'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

foreach ($dir in $dirs) {
    Get-ChildItem -Path $dir -Filter *.jpeg | ForEach-Object {
        $img = $_.FullName
        try {
            $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($img)) ([Windows.Storage.StorageFile])
            $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
            $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
            $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
            $text = $result.Text
            $safeName = ($_.BaseName -replace '[^\w\-]','_') + '.txt'
            Set-Content -Path (Join-Path $outDir $safeName) -Value $text -Encoding UTF8
            Write-Output "===== $($_.Name) ====="
            Write-Output $text
            Write-Output ""
        } catch {
            Write-Output "===== $($_.Name) : ERROR: $($_.Exception.Message) ====="
        }
    }
}
