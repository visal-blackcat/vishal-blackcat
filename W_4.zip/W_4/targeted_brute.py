from pypdf import PdfReader
import itertools

base_words = [
 '1234567890','123456789','12345678','1234567','123456','12345','1234','123','12',
 'password','Password','PASSWORD','password1','Password1','password123','Pass@123','p@ssw0rd','P@ssw0rd','Password@123',
 'qwerty','Qwerty','qwerty123','qwertyuiop','qwerty1','querty','qwerty12',
 'mediroza','Mediroza','MEDIROZA','mediroza2024','Mediroza2024','Mediroza@2024','medirozahospital','medirozahospital.com',
 'hospital','Hospital','hospital123','lab','Lab','lab123','patient','Patient','patient123','report','Report',
 'Dlamini','Reddy','Thompson','Sipho','Priya','Emily','sipho','priya','emily','dlamini','reddy','thompson',
 'LR-2024-1187','LR-2024-1192','LR-2024-1205','MG-P-10231','MG-P-10244','MG-P-10258',
 'letmein','admin','Admin','admin123','welcome','Welcome','welcome1','test','Test','test123','secret','secret123',
 'iloveyou','monkey','dragon','abc123','1q2w3e4r','qazwsx','zaq12wsx','111111','000000','654321','112233',
 'changeme','access','master','shadow','superman','batman','starwars','trustno1','whatever','freedom',
 'Pass123','pass123','pass','Pass','PASS','123abc','abc12345','Password@1','Mediroza!','Lab@2024','Patient@2024',
]
suffixes = ['', '1', '123', '2024', '2025', '2026', '!', '@', '#', '@123', '123!', '2024!', '01']
candidates = []
for w in base_words:
    for s in suffixes:
        candidates.append(w + s)
candidates = list(dict.fromkeys(candidates))

path = r'C:\Users\USER\Downloads\W_4\pdf_hash\patient_report_3.pdf'
r = PdfReader(path)
print('Trying', len(candidates), 'candidates')
for pw in candidates:
    try:
        if r.decrypt(pw):
            print('PASSWORD FOUND:', repr(pw))
            txt = '\n'.join((p.extract_text() or '') for p in r.pages)
            print(txt[:3000])
            open(r'C:\Users\USER\Downloads\W_4\pdf3_password.txt','w').write(pw)
            break
    except Exception:
        pass
else:
    print('No match')
