param([string]$ImagePath)
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap($ImagePath)
$w = $bmp.Width; $h = $bmp.Height
$buckets = @{}
for ($y = 0; $y -lt $h; $y += 2) {
    for ($x = 0; $x -lt $w; $x += 2) {
        $c = $bmp.GetPixel($x, $y)
        $r = $c.R; $g = $c.G; $b = $c.B
        $max = [Math]::Max($r, [Math]::Max($g, $b)); $min = [Math]::Min($r, [Math]::Min($g, $b))
        if ($max -gt 80 -and ($max - $min) -gt 40) {
            $key = "$( [Math]::Floor($x/100) * 100 ),$( [Math]::Floor($y/50) * 50 )"
            if (-not $buckets.ContainsKey($key)) { $buckets[$key] = 0 }
            $buckets[$key]++
        }
    }
}
$buckets.GetEnumerator() | Sort-Object { [int]($_.Key.Split(',')[1]) }, { [int]($_.Key.Split(',')[0]) } | ForEach-Object { "X=$($_.Key.Split(',')[0]) Y=$($_.Key.Split(',')[1]) count=$($_.Value)" }
$bmp.Dispose()
