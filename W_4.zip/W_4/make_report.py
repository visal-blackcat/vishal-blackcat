from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os

BASE = r'C:\Users\USER\Downloads\W_4'
HASH_DIR = os.path.join(BASE, 'pdf_hash')
PROOF_DIR = os.path.join(BASE, 'proof')
OUT = os.path.join(BASE, 'Mediroza_Forensics_Report.docx')

doc = Document()

# ---------- global styles ----------
normal = doc.styles['Normal']
normal.font.name = 'Calibri'
normal.font.size = Pt(10.5)
normal.paragraph_format.space_after = Pt(6)

for i, color in [(1, RGBColor(0x1F, 0x3B, 0x63)), (2, RGBColor(0x2E, 0x5C, 0x8A)), (3, RGBColor(0x3C, 0x76, 0xA8))]:
    st = doc.styles[f'Heading {i}']
    st.font.name = 'Calibri'
    st.font.color.rgb = color
    st.font.size = Pt(16 if i == 1 else 13 if i == 2 else 11.5)
    st.font.bold = True

def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def add_table(headers, rows, widths=None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for j, h in enumerate(headers):
        hdr[j].text = ''
        r = hdr[j].paragraphs[0].add_run(h)
        r.bold = True
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        r.font.size = Pt(9.5)
        set_cell_shading(hdr[j], '1F3B63')
    for row in rows:
        cells = t.add_row().cells
        for j, val in enumerate(row):
            cells[j].text = ''
            run = cells[j].paragraphs[0].add_run(str(val))
            run.font.size = Pt(9)
    if widths:
        for row in t.rows:
            for j, w in enumerate(widths):
                row.cells[j].width = Inches(w)
    doc.add_paragraph()
    return t

def add_image(path, caption, width=6.0):
    if not os.path.exists(path):
        doc.add_paragraph(f'[MISSING IMAGE: {path}]')
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(path, width=Inches(width))
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = cap.add_run(caption)
    r.italic = True
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    cap.paragraph_format.space_after = Pt(10)

def bullet(text):
    doc.add_paragraph(text, style='List Bullet')

# ======================= TITLE PAGE =======================
title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title.paragraph_format.space_before = Pt(90)
r = title.add_run('DIGITAL FORENSICS & OSINT\nINVESTIGATION REPORT')
r.bold = True
r.font.size = Pt(26)
r.font.color.rgb = RGBColor(0x1F, 0x3B, 0x63)

sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = sub.add_run('Mediroza General Hospital — Patient Portal &\nEncrypted Pathology Laboratory Reports')
r.font.size = Pt(15)
r.font.color.rgb = RGBColor(0x2E, 0x5C, 0x8A)

meta = doc.add_paragraph()
meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
meta.paragraph_format.space_before = Pt(50)
meta.add_run('Coursework: Week 4 — Password Forensics & Open-Source Intelligence\n').font.size = Pt(11)
meta.add_run('Report Date: 24 November 2026\n').font.size = Pt(11)
meta.add_run('Classification: Internal / Educational Use Only').font.size = Pt(11)

doc.add_page_break()

# ======================= 1. EXECUTIVE SUMMARY =======================
doc.add_heading('1. Executive Summary', 1)
doc.add_paragraph(
    'This report documents a digital forensic and open-source intelligence (OSINT) exercise '
    'centred on the domain medirozahospital.com and three password-protected pathology '
    'laboratory reports (PDF files) retrieved from the hospital patient portal. '
    'The work was carried out in a Kali Linux environment and covered four main tasks: '
    '(1) extraction of PDF password hashes using pdf2john, (2) recovery of the PDF passwords '
    'through dictionary attacks, (3) examination of the decrypted patient reports, and '
    '(4) domain and website reconnaissance using WHOIS, DNS (nslookup) and direct web browsing.'
)
doc.add_paragraph(
    'All three encrypted PDF files were successfully cracked and their contents examined. '
    'The recovered reports contain personally identifiable information (PII) and clinical '
    'laboratory results for three named patients. Supporting screenshots of every step '
    'are embedded in the relevant sections of this report as evidence figures.'
)

doc.add_heading('Key Results at a Glance', 2)
add_table(
    ['Item', 'Result'],
    [
        ['Encrypted PDFs analysed', '3 (patient_report_1.pdf, patient_report_2.pdf, patient_report_3.pdf)'],
        ['Hash format', 'John the Ripper $pdf$ format, RC4 128-bit (PDF /V 2, /R 3)'],
        ['Passwords recovered', '3 / 3 (100% success)'],
        ['Patients identified', 'Sipho Dlamini, Priya Reddy, Emily Thompson'],
        ['Domain investigated', 'medirozahospital.com'],
        ['Registrar', 'Namecheap, Inc. (privacy-protected registrant)'],
        ['Hosting / DNS', 'Namecheap Hosting name servers; A record 199.188.201.16'],
        ['Portal access', 'Patient portal exposed at /patient/portal.php; reports downloadable as encrypted PDFs'],
    ],
    widths=[1.9, 4.4]
)

# ======================= 2. SCOPE & EVIDENCE =======================
doc.add_heading('2. Scope and Evidence Inventory', 1)
doc.add_paragraph(
    'The evidence set consists of two folders: "pdf_hash", containing the encrypted PDFs, '
    'their extracted hash files and screenshots of the password-cracking process and the '
    'decrypted reports; and "proof", containing screenshots that document the OSINT and '
    'web-reconnaissance phase.'
)
add_table(
    ['File', 'Location', 'Description / Evidential Value'],
    [
        ['patient_report_1.pdf', 'pdf_hash', 'Encrypted pathology report (Sipho Dlamini)'],
        ['patient_report_2.pdf', 'pdf_hash', 'Encrypted pathology report (Priya Reddy)'],
        ['patient_report_3.pdf', 'pdf_hash', 'Encrypted pathology report (Emily Thompson)'],
        ['PDF_1.txt / PDF_2.txt / PDF_3.txt', 'pdf_hash', 'Extracted $pdf$ hashes used for offline cracking'],
        ['Password_1.jpeg, password_2.jpeg, password_3.jpeg', 'pdf_hash', 'Screenshots showing successful password recovery'],
        ['No_2.jpeg, No_1.jpeg, mediroza_riport.jpeg', 'pdf_hash', 'Screenshots of the decrypted laboratory reports'],
        ['web_index.jpeg, web_login.jpeg, file list.jpeg', 'proof', 'Hospital website landing page, staff login and patient file listing'],
        ['whois Part_1.jpeg, whois Part_2.jpeg', 'proof', 'WHOIS registration record for medirozahospital.com'],
        ['nslookup.jpeg', 'proof', 'DNS A-record and MX-record lookup results'],
    ],
    widths=[2.0, 0.9, 3.4]
)

# ======================= 3. HASH EXTRACTION & CRACKING =======================
doc.add_heading('3. Phase 1 — PDF Hash Extraction and Password Recovery', 1)

doc.add_heading('3.1 Hash Extraction', 2)
doc.add_paragraph(
    'Each encrypted PDF was processed with pdf2john (from the John the Ripper suite) to '
    'extract the password-verification hash. The resulting hashes were saved as PDF_1.txt, '
    'PDF_2.txt and PDF_3.txt. All three use the standard PDF encryption scheme: algorithm 2 '
    '(RC4), 128-bit key length, revision 3, with permissions value 4294967292. '
    'The full hash values are reproduced in Appendix A.'
)
add_table(
    ['Hash file', 'Source PDF', 'Format identifier', 'Encryption'],
    [
        ['PDF_1.txt', 'patient_report_1.pdf', '$pdf$2*3*128*…', 'RC4 128-bit, /R 3'],
        ['PDF_2.txt', 'patient_report_2.pdf', '$pdf$2*3*128*…', 'RC4 128-bit, /R 3'],
        ['PDF_3.txt', 'patient_report_3.pdf', '$pdf$ 2*3*128*…', 'RC4 128-bit, /R 3 (note: separators partly missing in captured text)'],
    ],
    widths=[1.2, 2.0, 1.5, 1.6]
)

doc.add_heading('3.2 Dictionary Attack and Recovered Passwords', 2)
doc.add_paragraph(
    'The extracted hashes were loaded into an offline PDF-password cracker and attacked '
    'with a built-in wordlist of common passwords. Each attack completed with a '
    '"PASSWORD CRACKED SUCCESSFULLY" message, as shown in the evidence figures below. '
    'The recovered credentials were then used to open the corresponding PDFs.'
)
add_table(
    ['PDF', 'Attack method', 'Recovered password', 'Evidence'],
    [
        ['patient_report_1.pdf', 'Dictionary attack (built-in list)', '123456', 'Figure 1'],
        ['patient_report_2.pdf', 'Dictionary attack (built-in list, 100 entries)', 'password', 'Figure 2'],
        ['patient_report_3.pdf', 'Dictionary attack (built-in list, 21 entries tried)', 'Recovered successfully — value displayed in Figure 3', 'Figure 3'],
    ],
    widths=[1.6, 2.1, 1.6, 0.9]
)

add_image(os.path.join(HASH_DIR, 'Password_1.jpeg'),
          'Figure 1 — Password recovery for PDF 1: the built-in wordlist attack reports '
          '"PASSWORD CRACKED SUCCESSFULLY" with the password 123456.', 6.0)
add_image(os.path.join(HASH_DIR, 'password_2.jpeg'),
          'Figure 2 — Password recovery for PDF 2: after trying "123456" the tool reports '
          'a match on the password "password".', 6.0)
add_image(os.path.join(HASH_DIR, 'password_3.jpeg'),
          'Figure 3 — Password recovery for PDF 3: successive dictionary candidates '
          '(password, 12345678, qwerty, 123456789, 12345, 1234 …) end with a successful match '
          'and the "PASSWORD CRACKED SUCCESSFULLY" banner.', 6.0)

doc.add_paragraph(
    'Assessment: the three passwords are extremely weak and would be recovered in seconds '
    'by any standard dictionary or rule-based attack. This represents a significant '
    'weakness in the protection of confidential patient data.'
)

# ======================= 4. PATIENT REPORTS =======================
doc.add_heading('4. Phase 2 — Decrypted Patient Laboratory Reports', 1)
doc.add_paragraph(
    'Using the recovered passwords, the three PDFs were opened and their contents examined. '
    'All reports originate from "Mediroza General Hospital, 14 Cedar Avenue, Johannesburg, '
    'South Africa" and are marked CONFIDENTIAL. The tables below summarise the clinical '
    'data, and the original report screenshots follow each summary.'
)

doc.add_heading('4.1 Report 1 — Sipho Dlamini (LR-2024-1187)', 2)
add_table(
    ['Field', 'Value'],
    [
        ['Patient name / ID', 'Sipho Dlamini — MG-P-10231'],
        ['Date of birth / Gender', '1984-06-12 — Male'],
        ['Report date', '2024-11-04'],
        ['Referring doctor', 'Dr. Anita Naicker'],
        ['Specimen', 'Whole blood (EDTA)'],
        ['Reported by', 'Dr. Rajesh Naidoo, MBBCh FCPath'],
    ],
    widths=[1.9, 4.4]
)
add_table(
    ['Test', 'Result', 'Unit', 'Reference range', 'Flag'],
    [
        ['Haemoglobin', '13.9', 'g/dL', '13.0 – 17.0', 'Normal'],
        ['White Cell Count', '11.8', '×10⁹/L', '4.0 – 11.0', 'HIGH'],
        ['Platelet Count', '245', '×10⁹/L', '150 – 400', 'Normal'],
        ['Fasting Glucose', '5.4', 'mmol/L', '3.9 – 5.5', 'Normal'],
        ['Creatinine', '88', 'µmol/L', '64 – 104', 'Normal'],
    ],
    widths=[1.6, 0.9, 0.9, 1.6, 0.9]
)
add_image(os.path.join(HASH_DIR, 'No_2.jpeg'),
          'Figure 4 — Decrypted pathology report for Sipho Dlamini (Lab Ref LR-2024-1187); '
          'the White Cell Count result is flagged HIGH.', 5.6)

doc.add_heading('4.2 Report 2 — Priya Reddy (LR-2024-1192)', 2)
add_table(
    ['Field', 'Value'],
    [
        ['Patient name / ID', 'Priya Reddy — MG-P-10244'],
        ['Date of birth / Gender', '1991-02-28 — Female'],
        ['Report date', '2024-11-05'],
        ['Referring doctor', 'Dr. Johan van der Merwe'],
        ['Specimen', 'Serum'],
        ['Reported by', 'Dr. Susan Botha, MBBCh FCPath'],
    ],
    widths=[1.9, 4.4]
)
add_table(
    ['Test', 'Result', 'Unit', 'Reference range', 'Flag'],
    [
        ['Total Cholesterol', '6.4', 'mmol/L', '< 5.0', 'HIGH'],
        ['LDL Cholesterol', '4.1', 'mmol/L', '< 3.0', 'HIGH'],
        ['HDL Cholesterol', '1.2', 'mmol/L', '> 1.0', 'Normal'],
        ['Triglycerides', '1.8', 'mmol/L', '< 1.7', 'HIGH'],
        ['Fasting Glucose', '4.9', 'mmol/L', '3.9 – 5.5', 'Normal'],
    ],
    widths=[1.6, 0.9, 0.9, 1.6, 0.9]
)
add_image(os.path.join(HASH_DIR, 'No_1.jpeg'),
          'Figure 5 — Decrypted pathology report for Priya Reddy (Lab Ref LR-2024-1192); '
          'Total Cholesterol, LDL and Triglycerides are flagged HIGH.', 5.6)

doc.add_heading('4.3 Report 3 — Emily Thompson (LR-2024-1205)', 2)
add_table(
    ['Field', 'Value'],
    [
        ['Patient name / ID', 'Emily Thompson — MG-P-10258'],
        ['Date of birth / Gender', '1978-09-03 — Female'],
        ['Report date', '2024-11-06'],
        ['Referring doctor', 'Dr. Ahmed Kara'],
        ['Specimen', 'Serum'],
        ['Report reference', 'LR-2024-1205'],
    ],
    widths=[1.9, 4.4]
)
add_table(
    ['Test', 'Result', 'Unit', 'Reference range', 'Flag'],
    [
        ['Haemoglobin', '11.4', 'g/dL', '12.0 – 15.5', 'LOW'],
        ['Ferritin', '9', 'µg/L', '15 – 150', 'LOW'],
        ['TSH', '3.1', 'mIU/L', '0.4 – 4.0', 'Normal'],
        ['Vitamin D', '42', 'nmol/L', '50 – 125', 'LOW'],
        ['Fasting Glucose', '5.1', 'mmol/L', '3.9 – 5.5', 'Normal'],
    ],
    widths=[1.6, 0.9, 0.9, 1.6, 0.9]
)
add_image(os.path.join(HASH_DIR, 'mediroza_riport.jpeg'),
          'Figure 6 — Decrypted pathology report for Emily Thompson (Lab Ref LR-2024-1205); '
          'Haemoglobin, Ferritin and Vitamin D are flagged LOW.', 5.6)

doc.add_paragraph(
    'All three reports state that they are confidential and intended only for the named '
    'patient and referring clinician, and that the laboratory is SANAS accredited '
    '(Ref M0417). The presence of full names, ID numbers, dates of birth and clinical '
    'results in weakly protected PDFs is a material data-protection concern.'
)

# ======================= 5. OSINT =======================
doc.add_heading('5. Phase 3 — OSINT and Domain Reconnaissance', 1)

doc.add_heading('5.1 Hospital Website and Patient Portal', 2)
doc.add_paragraph(
    'The public website presents Mediroza General Hospital as a private hospital offering '
    'specialist care, diagnostics and 24/7 emergency services, with an emergency contact '
    'number of +27 11 555 0100. A "Patient Portal" link and a "Staff Login" option are '
    'exposed on the home page. The patient portal at /patient/portal.php states that lab '
    'reports are password protected and lists three downloadable encrypted PDF reports, '
    'matching the files examined in Phase 2.'
)
add_image(os.path.join(PROOF_DIR, 'web_index.jpeg'),
          'Figure 7 — Mediroza General Hospital public website home page, showing navigation, '
          'emergency contact and the Patient Portal link.', 6.0)
add_image(os.path.join(PROOF_DIR, 'web_login.jpeg'),
          'Figure 8 — Patient Portal sign-in page (username/password form).', 6.0)
add_image(os.path.join(PROOF_DIR, 'file list.jpeg'),
          'Figure 9 — Patient portal file list: three encrypted pathology PDFs corresponding '
          'to S. Dlamini, P. Reddy and E. Thompson, with their lab references and dates.', 6.0)

doc.add_heading('5.2 WHOIS Lookup', 2)
doc.add_paragraph(
    'A WHOIS query for medirozahospital.com shows the domain is registered through '
    'Namecheap, Inc. The registrant identity is redacted for privacy via Withheld for '
    'Privacy LLC (16192 Coastal Highway, Lewes, Delaware, USA). The domain status is '
    'clientTransferProhibited and DNSSEC is unsigned. The registry expiry date is '
    '2027-08-14. Name servers are dns1.namecheaphosting.com and dns2.namecheaphosting.com.'
)
add_table(
    ['WHOIS field', 'Value'],
    [
        ['Domain', 'MEDIROZAHOSPITAL.COM'],
        ['Registrar', 'Namecheap, Inc. (IANA ID 1068), whois.namecheap.com'],
        ['Registrant', 'Redacted for privacy — Withheld for Privacy LLC, Delaware, US'],
        ['Domain status', 'clientTransferProhibited'],
        ['Name servers', 'dns1.namecheaphosting.com; dns2.namecheaphosting.com'],
        ['DNSSEC', 'unsigned'],
        ['Registry expiry', '2027-08-14'],
    ],
    widths=[1.7, 4.6]
)
add_image(os.path.join(PROOF_DIR, 'whois Part_1.jpeg'),
          'Figure 10 — WHOIS record (part 1): registry data, registrar, status and '
          'name-server information.', 4.3)
add_image(os.path.join(PROOF_DIR, 'whois Part_2.jpeg'),
          'Figure 11 — WHOIS record (part 2): privacy-protected registrant, administrative '
          'and technical contacts.', 4.1)

doc.add_heading('5.3 DNS / MX Lookup', 2)
doc.add_paragraph(
    'An nslookup query using Google DNS (8.8.8.8) resolved medirozahospital.com to the '
    'IPv4 address 199.188.201.16. The MX query returned three mail exchangers hosted by '
    'jenyfish.systems with priorities 5, 10 and 20, indicating that email for the domain '
    'is handled by a third-party provider rather than the web host.'
)
add_table(
    ['Record', 'Value', 'Priority'],
    [
        ['A', '199.188.201.16', '—'],
        ['MX', 'mx1-hosting.jenyfish.systems', '5'],
        ['MX', 'mx2-hosting.jenyfish.systems', '10'],
        ['MX', 'mx3-hosting.jenyfish.systems', '20'],
    ],
    widths=[0.9, 4.2, 1.2]
)
add_image(os.path.join(PROOF_DIR, 'nslookup.jpeg'),
          'Figure 12 — nslookup results: MX records (top) and A record 199.188.201.16 (bottom).', 4.8)

# ======================= 6. FINDINGS =======================
doc.add_heading('6. Findings and Conclusion', 1)
doc.add_paragraph('The investigation produced the following key findings:')
bullet('All three encrypted PDF reports were successfully decrypted using passwords '
       'recovered from dictionary attacks (123456, password, and the value shown in Figure 3).')
bullet('The passwords are trivial and are among the most common credentials in existence; '
       'PDF encryption alone therefore provided effectively no protection against a '
       'determined attacker with offline access to the files.')
bullet('The decrypted reports expose sensitive personally identifiable information and '
       'clinical results for three patients, including abnormal flagged values.')
bullet('The hospital website and patient portal are publicly reachable and disclose the '
       'existence, names and dates of the confidential reports before any authentication.')
bullet('The domain is privacy-protected and hosted externally; MX records point to a '
       'third-party mail provider (jenyfish.systems), which is useful for phishing and '
       'infrastructure-mapping assessments.')
bullet('Recommended remediation: enforce strong, unique, randomly generated passwords or '
       'certificate-based protection for reports; remove report metadata from public pages; '
       'implement rate limiting and MFA on the patient portal; and audit access logs.')

doc.add_paragraph()
end = doc.add_paragraph()
end.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = end.add_run('— End of Report —')
r.bold = True
r.font.color.rgb = RGBColor(0x1F, 0x3B, 0x63)

# ======================= APPENDIX =======================
doc.add_page_break()
doc.add_heading('Appendix A — Extracted PDF Hashes', 1)
doc.add_paragraph('The following hash strings were extracted from the three PDF files and '
                  'used in the password-recovery phase.')

with open(os.path.join(HASH_DIR, 'PDF_1.txt'), encoding='utf-8') as f:
    h1 = f.read().strip()
with open(os.path.join(HASH_DIR, 'PDF_2.txt'), encoding='utf-8') as f:
    h2 = f.read().strip()
with open(os.path.join(HASH_DIR, 'PDF_3.txt'), encoding='utf-8') as f:
    h3 = f.read().strip()

for label, h in [('PDF_1.txt — patient_report_1.pdf', h1),
                 ('PDF_2.txt — patient_report_2.pdf', h2),
                 ('PDF_3.txt — patient_report_3.pdf', h3)]:
    p = doc.add_paragraph()
    r = p.add_run(label + '\n')
    r.bold = True
    r.font.size = Pt(9.5)
    rr = p.add_run(h)
    rr.font.name = 'Consolas'
    rr.font.size = Pt(8)
    p.paragraph_format.space_after = Pt(12)

doc.save(OUT)
print('Saved:', OUT)
