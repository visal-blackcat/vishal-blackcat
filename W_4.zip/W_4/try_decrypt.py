from pypdf import PdfReader
import os

base = r'C:\Users\USER\Downloads\W_4\pdf_hash'
candidates = ['123456','password','qwerty','12345678','123456789','12345','1234','1234567',
              'letmein','admin','welcome','test','guest','111111','000000','abc123',
              'patient','mediroza','hospital','lab','report','secret','pass','pass123',
              'qwerty123','iloveyou','dragon','monkey','football','baseball','sunshine',
              'princess','master','hello','freedom','whatever','zaq12wsx','1q2w3e4r']

for i in range(1, 4):
    path = os.path.join(base, f'patient_report_{i}.pdf')
    r = PdfReader(path)
    print(f'--- patient_report_{i}.pdf encrypted={r.is_encrypted} ---')
    if not r.is_encrypted:
        txt = '\n'.join((p.extract_text() or '') for p in r.pages)
        print(txt[:2000])
        continue
    found = None
    for pw in candidates:
        try:
            res = r.decrypt(pw)
            if res:
                found = pw
                print(f'PASSWORD FOUND: {pw!r} (result={res})')
                break
        except Exception:
            pass
    if found:
        txt = '\n'.join((p.extract_text() or '') for p in r.pages)
        print(txt[:3000])
    else:
        print('No candidate matched.')
