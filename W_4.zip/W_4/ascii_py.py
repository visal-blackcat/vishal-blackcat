from PIL import Image
import sys

path = sys.argv[1]
x0, y0, w, h = map(int, sys.argv[2:6])
stepx = int(sys.argv[6]) if len(sys.argv) > 6 else 2
stepy = int(sys.argv[7]) if len(sys.argv) > 7 else 3
thr = int(sys.argv[8]) if len(sys.argv) > 8 else 25
img = Image.open(path).convert('RGB')
for y in range(y0, min(y0+h, img.height), stepy):
    line = ''
    for x in range(x0, min(x0+w, img.width), stepx):
        mx = 0
        for dy in range(stepy):
            for dx in range(stepx):
                px, py = x+dx, y+dy
                if px < img.width and py < img.height:
                    r, g, b = img.getpixel((px, py))
                    mx = max(mx, (r+g+b)//3)
        line += '#' if mx > thr else ' '
    print(line.rstrip())
