param([string]$ImagePath, [int]$X, [int]$Y, [int]$W, [int]$H)
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap($ImagePath)
$colors = @{}
for ($y = $Y; $y -lt [Math]::Min($Y+$H,$bmp.Height); $y++) {
  for ($x = $X; $x -lt [Math]::Min($X+$W,$bmp.Width); $x++) {
    $c = $bmp.GetPixel($x,$y)
    $key = "$($c.R),$($c.G),$($c.B)"
    if (-not $colors.ContainsKey($key)) { $colors[$key]=0 }
    $colors[$key]++
  }
}
$colors.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 20 | ForEach-Object { "$($_.Key) => $($_.Value)" }
$bmp.Dispose()
