from pypdf import PdfReader
import urllib.request

urls = [
 'https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Common-Credentials/100k-most-used-passwords-NCSC.txt',
 'https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Common-Credentials/10k-most-common.txt',
]
words = []
for u in urls:
    try:
        data = urllib.request.urlopen(u, timeout=30).read().decode('utf-8', 'ignore').splitlines()
        words.extend(w.strip() for w in data if w.strip())
        print(f'Loaded {len(data)} from {u.split("/")[-1]}')
    except Exception as e:
        print('fetch failed', e)
words = list(dict.fromkeys(words))
print('Total unique:', len(words))

path = r'C:\Users\USER\Downloads\W_4\pdf_hash\patient_report_3.pdf'
r = PdfReader(path)
for pw in words:
    try:
        if r.decrypt(pw):
            print('PASSWORD FOUND:', repr(pw))
            txt = '\n'.join((p.extract_text() or '') for p in r.pages)
            print(txt[:3000])
            open(r'C:\Users\USER\Downloads\W_4\pdf3_password.txt','w').write(pw)
            break
    except Exception:
        pass
else:
    print('No match')
