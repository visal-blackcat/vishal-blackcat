param([string]$ImagePath, [int]$X, [int]$Y, [int]$W, [int]$H)
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap($ImagePath)
for ($y = $Y; $y -lt [Math]::Min($Y+$H,$bmp.Height); $y++) {
  $cnt = 0
  for ($x = $X; $x -lt [Math]::Min($X+$W,$bmp.Width); $x++) {
    $c = $bmp.GetPixel($x,$y)
    if (($c.R + $c.G + $c.B) / 3 -gt 25) { $cnt++ }
  }
  if ($cnt -gt 5) { "Y=$y bright=$cnt" }
}
$bmp.Dispose()
