param([string]$ImagePath, [string]$Mode = 'green')
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap($ImagePath)
$w = $bmp.Width; $h = $bmp.Height
$out = New-Object System.Drawing.Bitmap($w, $h)
for ($y = 0; $y -lt $h; $y++) {
    for ($x = 0; $x -lt $w; $x++) {
        $c = $bmp.GetPixel($x, $y)
        $keep = $false
        switch ($Mode) {
            'green' { $keep = ($c.G -gt 90 -and $c.G -gt $c.R + 25 -and $c.G -gt $c.B + 25) }
            'red'   { $keep = ($c.R -gt 100 -and $c.R -gt $c.G + 40 -and $c.R -gt $c.B + 40) }
            'nonblue' { $keep = ($c.R -gt 100 -and $c.G -gt 100 -and $c.B -lt 120) }
        }
        if ($keep) { $out.SetPixel($x, $y, [System.Drawing.Color]::White) } else { $out.SetPixel($x, $y, [System.Drawing.Color]::Black) }
    }
}
$big = New-Object System.Drawing.Bitmap($out, ($w*3), ($h*3))
$out.Dispose(); $bmp.Dispose()
$tmp = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "mask_$Mode.png")
$big.Save($tmp, [System.Drawing.Imaging.ImageFormat]::Png)
$big.Dispose()
Write-Output $tmp
