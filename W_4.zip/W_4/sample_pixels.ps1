Add-Type -AssemblyName System.Drawing
$b = [System.Drawing.Bitmap]::FromFile('C:\Users\USER\Downloads\W_4\pdf_hash\password_3.jpeg')
foreach ($y in 0,50,100,150,200,250,300,350,400,450,500,550,600,650,700) {
    $c = $b.GetPixel(300, $y)
    Write-Output ("y={0} r={1} g={2} b={3} avg={4}" -f $y, $c.R, $c.G, $c.B, [int](($c.R+$c.G+$c.B)/3))
}
$b.Dispose()
