Add-Type -AssemblyName System.Drawing
$b = [System.Drawing.Bitmap]::FromFile('C:\Users\USER\Downloads\W_4\pdf_hash\password_3.jpeg')
$minX=9999; $maxX=0; $minY=9999; $maxY=0; $cnt=0; $samples=@()
for ($y=0; $y -lt $b.Height; $y++) {
  for ($x=0; $x -lt $b.Width; $x++) {
    $c = $b.GetPixel($x,$y)
    if (($c.R+$c.G+$c.B)/3 -gt 80) {
      $cnt++
      if ($x -lt $minX) {$minX=$x}; if ($x -gt $maxX) {$maxX=$x}
      if ($y -lt $minY) {$minY=$y}; if ($y -gt $maxY) {$maxY=$y}
      if ($samples.Count -lt 12) { $samples += "x=$x y=$y r=$($c.R) g=$($c.G) b=$($c.B)" }
    }
  }
}
Write-Output "count=$cnt bounds x:$minX-$maxX y:$minY-$maxY"
$samples
$b.Dispose()
