param([string]$ImagePath, [int]$X, [int]$Y, [int]$W, [int]$H, [int]$StepX = 2, [int]$StepY = 3, [int]$Threshold = 70)
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap($ImagePath)
$sb = New-Object System.Text.StringBuilder
for ($y = $Y; $y -lt [Math]::Min($Y+$H,$bmp.Height); $y += $StepY) {
  $line = ''
  for ($x = $X; $x -lt [Math]::Min($X+$W,$bmp.Width); $x += $StepX) {
    $max = 0
    for ($dy = 0; $dy -lt $StepY -and ($y+$dy) -lt $bmp.Height; $dy++) {
      for ($dx = 0; $dx -lt $StepX -and ($x+$dx) -lt $bmp.Width; $dx++) {
        $c = $bmp.GetPixel($x+$dx, $y+$dy)
        $b = [int](($c.R + $c.G + $c.B) / 3)
        if ($b -gt $max) { $max = $b }
      }
    }
    if ($max -gt $Threshold) { $line += '#' } else { $line += ' ' }
  }
  [void]$sb.AppendLine($line.TrimEnd())
}
$bmp.Dispose()
$sb.ToString()
